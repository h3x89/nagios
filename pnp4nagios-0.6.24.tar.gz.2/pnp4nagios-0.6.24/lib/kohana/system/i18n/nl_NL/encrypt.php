<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'De %s groep is niet gedefinieerd in je configuratie.',
	'requires_mcrypt'   => 'Om de Encrypt library te gebruiken, moet mcrypt ingeschakeld zijn in je PHP installatie.',
	'no_encryption_key' => 'Om de Encrypt library te gebruiken, moet je een encryption key zetten in je config bestand.',
);
