<!-- Header Template -->
<div class="p4 ui-widget-header ui-corner-all">
<?php echo $title ?>
</div>
